Pawfect Homes - frontend only

Features:
- 5 dogs with online photo URLs (Unsplash)
- Heartwarming descriptions
- Repeating soft-gray SVG paw background (assets/paw.svg)
- Adoption form opens when clicking Adopt This Dog; long scrollable form modeled on PAWS application
- No backend, frontend only
- Organized: models, views, widgets, services
- Uses flutter_staggered_grid_view and flutter_svg

Run:
flutter pub get
flutter create .
flutter run
