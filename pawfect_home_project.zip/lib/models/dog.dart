class Dog {
  final String name;
  final String breed;
  final String age;
  final String size;
  final String description;
  final String rescueStory;
  final String imageUrl;
  Dog({required this.name, required this.breed, required this.age, required this.size, required this.description, required this.rescueStory, required this.imageUrl});
}
