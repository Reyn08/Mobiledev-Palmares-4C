import 'models/dog.dart';
import 'package:flutter/material.dart';
import 'views/browse_dogs.dart';
import 'views/about_us.dart';
import 'views/adoption_form.dart';
import 'views/layouts/layouts_menu.dart';

void main() {
  runApp(const PawfectHomesApp());
}

class PawfectHomesApp extends StatelessWidget {
  const PawfectHomesApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Pawfect Homes',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primaryColor: const Color(0xFFEF8A49),
        scaffoldBackgroundColor: const Color(0xFFFDF6F0),
        colorScheme: ColorScheme.fromSwatch(primarySwatch: Colors.deepOrange).copyWith(secondary: const Color(0xFF8EC5C2)),
      ),
      routes: {
        '/': (context) => const HomeShell(),
      },
      onGenerateRoute: (settings) {
        if (settings.name == '/adopt') {
          final dog = settings.arguments as Dog;
          return MaterialPageRoute(builder: (_) => AdoptionFormView(dog: dog));
        }
        return null;
      },
    );
  }
}

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _selectedIndex = 0;
  final pages = [const BrowseDogsView(), const AboutUsView(), const LayoutsMenu()];

  void _onTap(int idx) => setState(() => _selectedIndex = idx);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(mainAxisSize: MainAxisSize.min, children: const [Text('🐾', style: TextStyle(fontSize:28)), SizedBox(width:8), Text('Pawfect Homes')]),
        centerTitle: true,
        backgroundColor: const Color(0xFFEF8A49),
      ),
      body: pages[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: _onTap,
        selectedItemColor: const Color(0xFFEF8A49),
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.info), label: 'About Us'),
          BottomNavigationBarItem(icon: Icon(Icons.view_list), label: 'Layouts'),
        ],
      ),
    );
  }
}
