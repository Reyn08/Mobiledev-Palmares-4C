import 'package:flutter/material.dart';
import '../widgets/custom_button.dart';

class AboutUsView extends StatelessWidget {
  const AboutUsView({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        
      ),
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Center(child: Row(mainAxisSize: MainAxisSize.min, children: const [Text('🐾', style: TextStyle(fontSize:36)), SizedBox(width:8), Text('Pawfect Homes', style: TextStyle(fontSize:28, fontWeight: FontWeight.bold))])),
          const SizedBox(height: 16),
          const Text('🐾 Mission', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          const Text('To rescue, rehabilitate, and lovingly rehome dogs in need — ensuring each dog is given medical care, emotional support, and a safe forever family.'),
          const Divider(height: 28),
          const Text('🐾 Vision', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          const Text('A compassionate community where every dog is valued and protected, and where rescue and responsible ownership are the first choice.'),
          const Divider(height: 28),
          const Text('🐾 Campaigns', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          const ListTile(leading: Text('🐾'), title: Text('Adopt, Don\'t Shop'), subtitle: Text('Encourage adoption and discourage buying from irresponsible sources.')),
          const ListTile(leading: Text('🐾'), title: Text('Paw for a Cause'), subtitle: Text('Community fundraisers and drives to support shelter care and medical needs.')),
          const ListTile(leading: Text('🐾'), title: Text('Educate to Rescue'), subtitle: Text('Programs teaching responsible pet ownership and the importance of spaying/neutering.')),
          const SizedBox(height: 12),
          Center(child: CustomButton(label: 'Join a Campaign', icon: Icons.volunteer_activism, onPressed: (){})),
          const SizedBox(height: 24),
        ]),
      ),
    );
  }
}
