import 'package:flutter/material.dart';
import '../../services/mock_dogs.dart';

class StackPetImage extends StatelessWidget {
  const StackPetImage({super.key});

  @override
  Widget build(BuildContext context) {
    final dog = dogs.first;
    return Stack(
      alignment: Alignment.bottomRight,
      children: [
        Positioned.fill(child: Image.network(dog.imageUrl, fit: BoxFit.cover)),
        Padding(
          padding: const EdgeInsets.all(16),
          child: FloatingActionButton(
            onPressed: ()=> ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Adopt pressed'))),
            child: const Icon(Icons.pets),
          ),
        )
      ],
    );
  }
}