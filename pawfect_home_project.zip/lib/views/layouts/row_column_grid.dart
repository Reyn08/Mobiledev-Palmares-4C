import 'package:flutter/material.dart';
import '../../services/mock_dogs.dart';

class RowColumnGrid extends StatelessWidget {
  const RowColumnGrid({super.key});

  @override
  Widget build(BuildContext context) {
    // Build a simple 2-column grid using Rows and Columns (no GridView)
    final tiles = dogs.map((d)=> GestureDetector(
      onTap: ()=> Navigator.push(context, MaterialPageRoute(builder: (_)=> Scaffold(
        appBar: AppBar(title: Text(d.name)),
        body: Center(child: Text(d.rescueStory)),
      ))),
      child: Column(
        children: [
          Image.network(d.imageUrl, width:150, height:100, fit: BoxFit.cover),
          const SizedBox(height:6),
          Text(d.name)
        ],
      ),
    )).toList();

    List<Widget> rows = [];
    for (var i=0;i<tiles.length;i+=2){
      final a = tiles[i];
      final b = (i+1<tiles.length)? tiles[i+1] : const SizedBox();
      rows.add(Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [Expanded(child: a), const SizedBox(width:8), Expanded(child: b)],
      ));
      rows.add(const SizedBox(height:12));
    }

    return SingleChildScrollView(
      padding: const EdgeInsets.all(12),
      child: Column(children: rows),
    );
  }
}