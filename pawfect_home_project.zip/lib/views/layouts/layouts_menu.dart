import 'package:flutter/material.dart';
import '../../models/dog.dart';
import '../layouts/row_three_status.dart';
import '../layouts/column_two_buttons.dart';
import '../layouts/padded_container_text.dart';
import '../layouts/profile_card.dart';
import '../layouts/expanded_row_compare.dart';
import '../layouts/nav_bar_row.dart';
import '../layouts/stack_pet_image.dart';
import '../layouts/flexible_column.dart';
import '../layouts/chat_bubble.dart';
import '../layouts/row_column_grid.dart';

class LayoutsMenu extends StatelessWidget {
  const LayoutsMenu({super.key});

  @override
  Widget build(BuildContext context) {
    final List<Map<String, dynamic>> items = [
      {'title':'Adoption Statuses','widget': const RowThreeStatus()},
      {'title':'Actions','widget': const ColumnTwoButtons()},
      {'title':'Rescue Story','widget': const PaddedContainerText()},
      {'title':'Pet Profile','widget': const ProfileCardLayout()},
      {'title':'Compare Pets','widget': const ExpandedRowCompare()},
      {'title':'Quick Nav','widget': const NavBarRow()},
      {'title':'Pet Showcase','widget': const StackPetImage()},
      {'title':'Responsive Details','widget': const FlexibleColumnLayout()},
      {'title':'Adoption Chat','widget': const ChatBubbleUI()},
      {'title':'Pet Grid','widget': const RowColumnGrid()},
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('Layouts Menu')),
      body: ListView.separated(
        itemCount: items.length,
        separatorBuilder: (_,__)=> const Divider(height:1),
        itemBuilder: (context, idx){
          final it = items[idx];
          return ListTile(
            title: Text(it['title']),
            subtitle: Text('Opens a layout used in-app'),
            trailing: const Icon(Icons.chevron_right),
            onTap: (){
              Navigator.push(context, MaterialPageRoute(builder: (_)=> Scaffold(
                appBar: AppBar(title: Text(it['title'])),
                body: Padding(padding: const EdgeInsets.all(12), child: it['widget']),
              )));
            },
          );
        },
      ),
    );
  }
}