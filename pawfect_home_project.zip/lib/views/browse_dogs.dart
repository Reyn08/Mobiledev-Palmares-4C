import 'package:flutter/material.dart';
import 'package:flutter_staggered_grid_view/flutter_staggered_grid_view.dart';
import '../services/mock_dogs.dart';
import '../widgets/dog_card.dart';
import 'dog_detail.dart';

class BrowseDogsView extends StatefulWidget {
  const BrowseDogsView({super.key});

  @override
  State<BrowseDogsView> createState() => _BrowseDogsViewState();
}

class _BrowseDogsViewState extends State<BrowseDogsView> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: MasonryGridView.count(
          crossAxisCount: 2,
          mainAxisSpacing: 8,
          crossAxisSpacing: 8,
          itemCount: dogs.length,
          itemBuilder: (context, index) {
            final dog = dogs[index];
            return InkWell(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => DogDetailView(dog: dog),
                  ),
                );
              },
              child: DogCard(dog: dog),
            );
          },
        ),
      ),
    );
  }
}
